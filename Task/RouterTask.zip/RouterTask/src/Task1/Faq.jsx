import React from 'react'

const Faq = () => {
  return (
    <div>
      <h1 className='heading'>This is Faq page.</h1>
    </div>
  )
}

export default Faq
