import React from 'react'

const ContatUs = () => {
  return (
    <div>
      <h1 className='heading'>This is ContactUs page.</h1>
    </div>
  )
}

export default ContatUs
