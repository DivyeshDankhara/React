import './App.css'
// import Task1 from './Task1/Task1'
// import Task2 from './Task2/Task2'
import Task5 from './Task5/Task5'
import Task6 from './Task6/Task6'
import Task7 from './Task7/Task7'

function App() {

  return (
    <>
    {/* <Task1/> */}
    {/* <Task2/> */}
    {/* <Task5/> */}
    {/* <Task6/> */}
    <Task7/>
    </>
  )
}

export default App
