import React from 'react'

const Error = () => {
  return (
    <div className='flex flex-col justify-center '>
      <h1 className='bg-blue-800'>404</h1>
      <p>Erro Page</p>
    </div>
  )
}

export default Error
