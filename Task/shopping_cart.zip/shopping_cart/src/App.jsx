import './App.css'
import Layout from './page/Layout'
import Shop from './page/Shop'

function App() {

  return (
    <>
      <Layout />
    </>
  )
}

export default App
