import './App.css'
import Redux from './Redux'

function App() {

  return (
    <>
      <Redux />
    </>
  )
}

export default App
