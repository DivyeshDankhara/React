export const Black = () => {
    return {
        type: "BLACK"
    }
}
export const White = () => {
    return {
        type: "WHITE"
    }
}