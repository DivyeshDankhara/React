import Reducer from "./Reducer"
import { createStore } from "redux"


export const Store = createStore(Reducer)
